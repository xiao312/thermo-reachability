"""Reproducible environment audit and small thermochemical-reachability checks.

These are smoke tests, not a validation of detailed combustion kinetics or a
certification that random sampling has found a complete reachable set.
Run: python verify.py --output results.json
Dependencies: numpy, scipy, sympy.
"""
from __future__ import annotations

import argparse
import importlib.metadata as metadata
import json
import os
from pathlib import Path
import platform
import shutil
import sys
import time

import numpy as np
import scipy
from scipy.integrate import solve_ivp
import sympy as sp


def audit() -> dict:
    result = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "visible_logical_cpus": os.cpu_count(),
        "cpu_affinity_count": len(os.sched_getaffinity(0))
        if hasattr(os, "sched_getaffinity") else None,
        "packages": {},
        "executables": {s: shutil.which(s) for s in (
            "gcc", "g++", "cmake", "git", "mpirun", "nvidia-smi",
            "foamVersion", "blockMesh", "simpleFoam")},
    }
    for field, name in (("cpu_max", "cpu.max"), ("memory_max", "memory.max")):
        file = Path("/sys/fs/cgroup") / name
        result[field] = file.read_text().strip() if file.exists() else None
    if result["cpu_max"]:
        quota, period = result["cpu_max"].split()
        result["cpu_quota_equivalent_cores"] = (
            float(quota) / float(period) if quota != "max" else None
        )
    if result["memory_max"] and result["memory_max"] != "max":
        result["memory_limit_GiB"] = int(result["memory_max"]) / 2**30
    for name in ("numpy", "scipy", "sympy", "matplotlib", "pandas", "cantera",
                 "CoolProp", "torch", "jax", "numba", "cvxpy", "pytest"):
        try:
            result["packages"][name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            result["packages"][name] = None
    result["exposed_nvidia_devices"] = [str(p) for p in Path("/dev").glob("nvidia*")]
    result["numpy_scipy_import_success"] = True
    return result


def cstr_checks() -> dict:
    # Nondimensional time: both first-order reaction rate constants are k=1.
    # A -> B -> C, equal molecular weights, pure-A feed.
    x, y = sp.symbols("x y", positive=True)
    gamma = sp.symbols("gamma", nonnegative=True)
    V = y + x * sp.log(x)
    dx = -x + gamma * (1-x)
    dy = x - y - gamma * y
    boundary_derivative = sp.simplify(
        (sp.diff(V, x)*dx + sp.diff(V, y)*dy).subs(y, -x*sp.log(x))
    )
    assert sp.simplify(boundary_derivative - gamma*(sp.log(x)+1-x)) == 0

    def exact(q0: np.ndarray, rate: float, t: np.ndarray) -> np.ndarray:
        a = 1.0 + rate
        xs = rate/a
        ys = rate/a**2
        e = np.exp(-a*t)
        xx = xs + (q0[0]-xs)*e
        yy = ys + (q0[1]-ys + (q0[0]-xs)*t)*e
        return np.array([xx, yy])

    start = time.perf_counter()
    batch_times = np.linspace(0, 12, 401)
    batch = solve_ivp(
        lambda t,q: [-q[0], q[0]-q[1]], (0,12), [1.0,0.0],
        method="Radau", t_eval=batch_times, rtol=1e-10, atol=1e-12,
    )
    assert batch.success, batch.message
    batch_error = float(np.max(np.abs(batch.y-exact(np.array([1.,0.]),0.,batch_times))))
    assert batch_error < 1e-8

    rng = np.random.default_rng(20260915)
    n_histories, n_segments = 32, 8
    max_exact_error = 0.0
    max_barrier = 0.0
    min_fraction = 0.0
    tested_states = 0
    total_nfev = 0
    for _ in range(n_histories):
        q = np.array([1.0, 0.0])
        for _ in range(n_segments):
            rate = 0.0 if rng.random() < 0.25 else float(10**rng.uniform(-3,2))
            duration = float(rng.uniform(0.02, 0.5))
            times = np.linspace(0.0, duration, 9)
            initial = q.copy()
            sol = solve_ivp(
                lambda t,q: [-q[0]+rate*(1-q[0]), q[0]-(1+rate)*q[1]],
                (0,duration), initial, method="Radau", t_eval=times,
                jac=np.array([[-1-rate,0.0],[1.0,-1-rate]]),
                rtol=1e-9, atol=1e-12,
            )
            assert sol.success, sol.message
            ref = exact(initial, rate, times)
            max_exact_error = max(max_exact_error, float(np.max(np.abs(sol.y-ref))))
            xx, yy = sol.y
            barrier = yy + xx*np.log(np.maximum(xx,np.finfo(float).tiny))
            max_barrier = max(max_barrier, float(np.max(barrier)))
            min_fraction = min(min_fraction, float(np.min(np.array([xx,yy,1-xx-yy]))))
            tested_states += sol.t.size
            total_nfev += sol.nfev
            q = sol.y[:,-1]
    assert max_exact_error < 1e-7
    assert max_barrier < 1e-8
    assert min_fraction > -1e-8
    return {
        "model": "isothermal A -> B -> C, k1=k2=1, pure-A feed",
        "barrier": "V(x,y)=y+x*log(x) <= 0",
        "symbolic_boundary_derivative": str(boundary_derivative),
        "symbolic_identity_verified": True,
        "sign_argument": "gamma >= 0 and log(x)+1-x <= 0 for 0<x<=1",
        "batch_max_absolute_error_against_exact_solution": batch_error,
        "random_seed": 20260915,
        "controlled_histories": n_histories,
        "segments_per_history": n_segments,
        "sampled_states_including_repeated_segment_endpoints": tested_states,
        "gamma_range_sampled": [0,100],
        "segment_duration_range": [0.02,0.5],
        "controlled_radau_max_absolute_error_against_exact_segment_solution": max_exact_error,
        "maximum_positive_barrier_violation": max_barrier,
        "minimum_species_fraction_or_zero": min_fraction,
        "total_controlled_radau_rhs_evaluations": total_nfev,
        "wall_seconds": time.perf_counter()-start,
        "scope": "Tests an upper invariant bound. Random histories do not establish complete reachability or attainability of every point in the bound.",
        "passed": True,
    }


def stiff_checks() -> dict:
    # A three-variable stiff reaction system (often called the Robertson system).
    # Concentrations are nondimensional; this is not a detailed combustion model.
    def rhs(t, q):
        a,b,c=q
        v1=0.04*a
        v2=1.0e4*b*c
        v3=3.0e7*b*b
        return [-v1+v2, v1-v2-v3, v3]

    def jac(t, q):
        a,b,c=q
        return np.array([
            [-0.04, 1.0e4*c, 1.0e4*b],
            [0.04, -1.0e4*c-6.0e7*b, -1.0e4*b],
            [0.0, 6.0e7*b, 0.0],
        ])

    times=np.r_[0., np.geomspace(1e-8,1e5,400)]
    runs={}
    solutions={}
    specs=(
        ("Radau", "Radau", 1e-9, [1e-12,1e-16,1e-12]),
        ("BDF", "BDF", 1e-9, [1e-12,1e-16,1e-12]),
        ("Radau_tighter_reference", "Radau", 1e-11, [1e-14,1e-18,1e-14]),
    )
    for name, method, rtol, atol in specs:
        start=time.perf_counter()
        sol=solve_ivp(rhs,(0.,1e5),[1.,0.,0.],method=method,jac=jac,
                      rtol=rtol,atol=atol,t_eval=times)
        elapsed=time.perf_counter()-start
        assert sol.success, sol.message
        conservation_error=float(np.max(np.abs(sol.y.sum(axis=0)-1)))
        minimum=float(sol.y.min())
        assert conservation_error<1e-9
        assert minimum>-1e-10
        solutions[name]=sol.y
        runs[name]={
            "success": bool(sol.success), "method": method,
            "rtol": rtol, "atol": atol,
            "wall_seconds": elapsed, "nfev": sol.nfev,
            "njev": sol.njev, "nlu": sol.nlu,
            "maximum_conservation_error": conservation_error,
            "minimum_concentration": minimum,
            "final_state": sol.y[:,-1].tolist(),
        }
    ref=solutions["Radau_tighter_reference"]
    for name in ("Radau","BDF"):
        err=float(np.max(np.abs(solutions[name]-ref)))
        runs[name]["maximum_absolute_difference_from_tighter_reference"]=err
        assert err<1e-7
    difference=float(np.max(np.abs(solutions["Radau"]-solutions["BDF"])))
    return {
        "model": "three-variable stiff reaction system; not detailed combustion",
        "integration_time_interval": [0,1e5],
        "common_output_time_count": len(times),
        "runs": runs,
        "maximum_absolute_radau_bdf_difference": difference,
        "interpretation": "Cross-method and tighter-tolerance agreement are numerical checks, not a rigorous interval enclosure or proof of global solver accuracy.",
        "passed": True,
    }


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=Path("results.json"))
    args=parser.parse_args()
    report={"environment":audit(),"cstr":cstr_checks(),"stiff_ode":stiff_checks()}
    report["all_tests_passed"]=True
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
