# Thermochemical research environment: executed smoke tests

This package contains actual tests executed in the chat's CPU sandbox. It is a
starting point for reproducing a few small mathematical and numerical checks,
not a completed reachable-set study or a benchmark of detailed combustion.

## Run

Tested with Python 3.13.5. The numerical packages are pinned in requirements.txt.
Use an interpreter compatible with those package versions.

```bash
python -m pip install -r requirements.txt
python verify.py --output local_results.json
```

The output records the local machine's observed environment and the numerical
results. Wall-clock timings depend on the machine and its concurrent load.
All tests use one process; the recorded CPU quota is not a parallel-scaling test.

## Test 1: analytical and controlled CSTR

The equal-rate, equal-molecular-weight, isothermal A -> B -> C model uses pure-A
feed and dimensionless reaction rate k=1. The coordinates are x=Y_A, y=Y_B,
with Y_C=1-x-y. Its equations are

    dx/dt = -x + gamma*(1-x)
    dy/dt = x - (1+gamma)*y

The proposed upper invariant boundary is V=y+x*log(x)=0. SymPy verifies

    dV/dt on V=0 = gamma*(log(x)+1-x).

For gamma>=0 and 0<x<=1, this is nonpositive by log(x)<=x-1.
The analytical proof of a complete reachable set requires additional arguments
and a precise admissible-control class; symbolic identity verification alone
is not that proof.

The script also compares Radau integration against the exact batch solution
and exact constant-control segment solutions for 32 randomly generated control
histories, with 8 segments per history. These tests do not prove that sampling
has covered a reachable set. Their 2,304 sampled output states include repeated
segment endpoints. Species positivity and the proposed upper bound are tested
up to numerical tolerances, not using rigorous interval arithmetic.

## Test 2: stiff ODE consistency

A three-variable stiff reaction system is integrated with Radau and BDF over
0<=t<=100000. Both are compared at 401 output times to a tighter-tolerance Radau
solution. The species sum and nonnegativity are checked. The script contains
the explicit equations and analytical Jacobian.

The tighter-tolerance solution is a numerical reference, not an exact solution.
Agreement at sampled output times does not certify all intermediate times or
exclude a shared implementation error. This is not a detailed combustion
mechanism, Cantera test, CFD test, or counterflow-flame calculation.

## Environment limitations observed in this session

- CPU quota: equivalent to 4 cores; memory limit: 4 GiB.
- No exposed NVIDIA device; PyTorch is a CPU-only build.
- Cantera and CoolProp were not installed.
- No configured OpenFOAM or MPI executables were found on PATH.
- Installing Cantera through pip failed because the runtime could not resolve
  the package host. A separate metadata-download attempt also failed.

The JSON results capture the actual numerical outputs, tolerances, solver
statistics, measured wall times, and available package versions. Resource
limits and package availability may differ in another session.
